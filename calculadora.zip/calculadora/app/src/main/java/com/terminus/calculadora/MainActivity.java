package com.terminus.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Declarando os botões.

    TextView textView_resultado, textView_operacao;
    MaterialButton botao_limpar,botao_abreParenteses,botao_fechaParenteses;
    MaterialButton botao_multiplicar,botao_dividir,botao_subtrair,botao_somar,botao_igual;
    MaterialButton botao_0,botao_1,botao_2,botao_3,botao_4,botao_5,botao_6,botao_7,botao_8,botao_9;
    MaterialButton botao_limparTudo,botao_ponto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Declarando as Ids das text views.

        textView_resultado = findViewById(R.id.textView_resultado);
        textView_operacao = findViewById(R.id.textView_operacao);

        // Atribuindo a id aos botões da calculadora.

        assignId(botao_limpar,R.id.button_limpar);
        assignId(botao_abreParenteses,R.id.button_abre_parenteses);
        assignId(botao_fechaParenteses,R.id.button_fecha_parenteses);
        assignId(botao_limparTudo,R.id.button_apagar_tudo);
        assignId(botao_somar,R.id.button_somar);
        assignId(botao_subtrair,R.id.button_subtrair);
        assignId(botao_multiplicar,R.id.button_multiplicar);
        assignId(botao_dividir,R.id.button_dividir);
        assignId(botao_igual,R.id.button_igual);
        assignId(botao_0,R.id.button_0);
        assignId(botao_1,R.id.button_1);
        assignId(botao_2,R.id.button_2);
        assignId(botao_3,R.id.button_3);
        assignId(botao_4,R.id.button_4);
        assignId(botao_5,R.id.button_5);
        assignId(botao_6,R.id.button_6);
        assignId(botao_7,R.id.button_7);
        assignId(botao_8,R.id.button_8);
        assignId(botao_9,R.id.button_9);
        assignId(botao_0,R.id.button_0);
        assignId(botao_ponto,R.id.button_ponto);

    }

    // Criando um método para atribuir a id de cada botão.

    void assignId(MaterialButton button,int id){
         button = findViewById(id);
         button.setOnClickListener(this);
    }

    // Criando um método que irá concatenar os números ao serem pressionados na textview de resultado.
    @Override
    public void onClick(View view) {
        MaterialButton button = (MaterialButton) view;
        String buttonText = button.getText().toString();
        String data_calculo = textView_resultado.getText().toString();


        // Criando uma condicional caso o botão apertado seja o AC e fazendo com que ele apague a tela ao ser pressionado.

        if(buttonText.equals("AC")){
            textView_operacao.setText("");
            textView_resultado.setText("0");
            return;
        }


        // Criando um método que irá apagar o último número informado caso o botão seja o de apagar(C).

        if(buttonText.equals("C")){
            data_calculo = data_calculo.substring(0,data_calculo.length()-1);
         }else{
            data_calculo = data_calculo + buttonText;
        }

        // Criando uma condicional caso o botão de igual (=) seja pressionado, ele passe o conteúdo da textview de resultado para a textview de cima (que irá mostrar a conta efetuada.

        if(buttonText.equals("=")){
            textView_resultado.setText(textView_resultado.getText());
            return;
        }

        // Pegando o resultado da conta inserida.
        textView_resultado.setText(data_calculo);

        String resultadoFinal = getResult(data_calculo);



        // Criando uma condicional para o próximo número informado não sair seguido de ".0".

        if(resultadoFinal.endsWith(".0")){
            resultadoFinal = resultadoFinal.replace(".0","");
        }

        // Criando uma condicional caso a conta inserida não dê erro.

        if(!resultadoFinal.equals("erro")){
            textView_resultado.setText(resultadoFinal);
        }
    }


    String getResult(String data){
        try {
            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            String resultadoFinal = context.evaluateString(scriptable,data, "javascript", 1, null).toString();
            return resultadoFinal;
        }catch (Exception e){
            return "erro";
        }
    }



}